def calculate_sum(arr)
    total = 0
    for num in arr:
        total += num
    return total
