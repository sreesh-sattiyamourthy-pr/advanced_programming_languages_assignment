def add(a, b):
    return a + b

print(add(5, 3))         # 8 (int)
print(add("5", "3"))     # "53" (str)
print(add([1, 2], [3]))  # [1, 2, 3] (list)
